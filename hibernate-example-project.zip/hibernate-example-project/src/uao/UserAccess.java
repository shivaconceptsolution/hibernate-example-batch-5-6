package uao;

import java.util.Scanner;

import bao.StudentCrud;

public class UserAccess {
    
	public static void main(String[] args) {
		int rno;
		String sname;
		String branch;
		int fees;
		Scanner sc = new Scanner(System.in);
		StudentCrud obj = new StudentCrud();
		boolean b=true;
		while(b)
		{
			StringBuilder sb = new StringBuilder();
			sb.append("Press 1 for Insertion\n Press 2 for updation \n Press 3 for deletion \n Press 4 for selection" );
			System.out.println(sb);
		
			switch(sc.nextInt())
			{
			case 1:
				System.out.println("Enter rno");
				rno=sc.nextInt();
				System.out.println("Enter name ");
				sname = sc.next();
				System.out.println("Enter branch ");
				branch = sc.next();
				System.out.println("Enter fees ");
				fees = sc.nextInt();
				obj.insertRecord(rno,sname,branch,fees);
				break;
			case 2:
				obj.updateRecord();
				break;
			case 3:
				obj.deleteRecord();
				break;
			case 4:
				obj.selectRecord();
				break;
			case 5:
				b=false;
				break;
			
			}
			
			
		}

	}

}
