package scs;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;



public class ViewAllStudent {
public static void main(String args[])
{
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf= cfg.buildSessionFactory();
	Session s = sf.openSession();
	Criteria ct = s.createCriteria(Student.class);
	ProjectionList p1=Projections.projectionList();
	p1.add(Projections.property("rno"));
	p1.add(Projections.property("fees"));
    ct.setProjection(p1);
	//Criterion rt = Restrictions.ge("fees",20000);
	//Criterion rt = Restrictions.between("fees", 50000,550000);
	/*ArrayList<Integer> aa = new ArrayList<Integer>();
	aa.add(1002);
	aa.add(1111);
	Criterion rt = Restrictions.in("rno",aa);
	ct.add(rt);*/
	
	List lst = ct.list();
	Iterator it = lst.iterator();
	while(it.hasNext())
	{
		Object o[] =(Object[]) it.next();
		
System.out.println(o[0] + " "+o[1]);
		
	}
	s.close();
	sf.close();
	
	
	
	
}
}
