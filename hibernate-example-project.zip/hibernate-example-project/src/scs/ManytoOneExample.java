package scs;


import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class ManytoOneExample {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); 
		SessionFactory sf = new AnnotationConfiguration().configure().buildSessionFactory();
		Session s = sf.openSession();
		Dept d = new Dept();
		d.setDeptid(10);
		d.setDeptname("IT");
		Employee em = new Employee();
		em.setEmpid(1001);
		em.setEmpname("XYZ");
		
		Employee em1 = new Employee();
		em1.setEmpid(1002);
		em1.setEmpname("ABC");
		
		Set st = new HashSet<>();
		st.add(em);
		st.add(em1);
	    d.setEmpref(st);
	    Transaction tx = s.beginTransaction();
	    s.save(d);
	    tx.commit();
	    s.close();
	    sf.close();

	}

}
