package bao;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import dao.DataHelper;
import scs.Student;

public class StudentCrud {
public void insertRecord(int rno, String sname,String branch, int fees)
{
	DataHelper.connection();
	Student stu = new Student();
	stu.setRno(rno);
	stu.setSname(sname);
	stu.setBranch(branch);
	stu.setFees(fees);
	DataHelper.dmlOperation(stu);
	DataHelper.closeConn();
}

public void updateRecord()
{
	Scanner sc = new Scanner(System.in);
	DataHelper.connection();
	System.out.println("Enter rno to update record");
	int rno = sc.nextInt();
	Student st =(Student)DataHelper.findOperation(Student.class,rno);
	System.out.println(st.getRno()+" "+st.getSname());
	st.setRno(rno);
	System.out.println("Enter name to update record");
	String sname = sc.next();
	st.setSname(sname);
	st.setBranch("EX");
	st.setFees(555555);
	DataHelper.dmlOperation(st);
	DataHelper.closeConn();
	
}

public void deleteRecord()
{
	Scanner sc = new Scanner(System.in);
	DataHelper.connection();
	System.out.println("Enter rno to update record");
	int rno = sc.nextInt();
	Student st =(Student)DataHelper.findOperation(Student.class,rno);
	DataHelper.deleteOperation(st);
	DataHelper.closeConn();
}
public void selectRecord()
{
     DataHelper.connection();
	
	List lst = DataHelper.dqlOperation("from Student s");
	
	Iterator it = lst.iterator();
	while(it.hasNext())
	{
		Object o = it.next();
		Student stu = (Student)o;
		System.out.println(stu.getRno() + " "+stu.getSname() + " "+stu.getBranch() + " "+stu.getFees());
		
	}
	
	DataHelper.closeConn();
}

}
